#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cianfrusacc-IA (BASE)
- /start, /help
- /cerca <query|link Amazon>: estrae titolo, prezzo, eventuale coupon dall'URL Amazon (pagina prodotto)
- /post <link Amazon>: genera un post breve (titolo + prezzo + link con tag)
- Config tramite settings.json
NOTE: è un esempio "base": scraping semplice lato HTML. Per volumi seri conviene usare API ufficiali.
"""
import os, re, json, time, logging, html
from urllib.parse import urlparse, parse_qs, urlunparse, urlencode

import requests
from bs4 import BeautifulSoup
import telebot

# ---------- Config ----------
HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(HERE, "settings.json")
with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
    S = json.load(f)

TOKEN          = S["TELEGRAM_TOKEN"]
AFFILIATE_TAG  = S.get("AFFILIATE_TAG","")
OWNER_ID       = int(S.get("OWNER_ID", 0))

bot = telebot.TeleBot(TOKEN, parse_mode="HTML")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

AMZN_HOSTS = ("amazon.it","www.amazon.it","amzn.to","www.amzn.to")

def add_tag_to_url(url: str, tag: str) -> str:
    """Aggiunge il tag affiliato ?tag= al link Amazon se mancante."""
    try:
        u = urlparse(url)
        if not u.netloc:
            return url
        if "amazon." not in u.netloc:
            return url
        q = parse_qs(u.query)
        if tag and "tag" not in q:
            q["tag"] = [tag]
        new_q = urlencode({k:v[0] for k,v in q.items()})
        return urlunparse((u.scheme,u.netloc,u.path,u.params,new_q,u.fragment))
    except Exception:
        return url

def expand_amzn(url: str) -> str:
    """Espande amzn.to (short) seguendo i redirect."""
    try:
        with requests.Session() as s:
            r = s.head(url, allow_redirects=True, timeout=12)
            return r.url
    except Exception:
        return url

def fetch_product(url: str) -> dict:
    """Scarica titolo, prezzo e coupon (se presente) da una pagina prodotto Amazon.it"""
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
    }
    if "amzn.to" in url:
        url = expand_amzn(url)
    res = requests.get(url, headers=headers, timeout=20)
    res.raise_for_status()
    soup = BeautifulSoup(res.text, "html.parser")

    # Titolo
    title = soup.select_one("#productTitle")
    title = title.get_text(strip=True) if title else "Titolo non trovato"

    # Prezzo (tentativi multipli)
    price_sel = [
        "#priceblock_ourprice", "#priceblock_dealprice",
        "#priceblock_saleprice", ".a-price .a-offscreen"
    ]
    price = None
    for css in price_sel:
        el = soup.select_one(css)
        if el and el.get_text(strip=True):
            price = el.get_text(strip=True)
            break

    # Coupon (es: "Applica coupon X€" o badge coupon)
    coupon = None
    coupon_badges = soup.find_all(string=re.compile(r"coupon", re.I))
    if coupon_badges:
        # prova ad estrarre importo
        import re as _re
        m = _re.search(r"(\d+[,.]?\d*)\s*€", " ".join(cb.strip() for cb in coupon_badges if cb))
        coupon = f"Applica coupon {m.group(1)}€" if m else "Coupon disponibile"

    return {"title": title, "price": price, "coupon": coupon, "url": url}

# ---------- Bot Handlers ----------

@bot.message_handler(commands=["start","help"])
def cmd_start(m):
    bot.reply_to(m, (
        "👋 Benvenuto su <b>Cianfrusacc‑IA</b> (pacchetto <i>Base</i>).\n\n"
        "<b>Comandi:</b>\n"
        "• <code>/cerca &lt;link Amazon o query&gt;</code>\n"
        "• <code>/post &lt;link Amazon&gt;</code> → messaggio pronto con titolo+prezzo\n\n"
        f"Tag affiliato attuale: <code>{html.escape(AFFILIATE_TAG or '—')}</code>"
    ))

@bot.message_handler(commands=["cerca"])
def cmd_cerca(m):
    q = m.text.split(maxsplit=1)
    if len(q) == 1:
        bot.reply_to(m,"Inviami: <code>/cerca &lt;link Amazon o query&gt;</code>")
        return
    arg = q[1].strip()

    # Se sembra un URL Amazon, estrai info
    if any(h in arg for h in AMZN_HOSTS):
        try:
            data = fetch_product(arg)
            tag_url = add_tag_to_url(data["url"], AFFILIATE_TAG)
            lines = [f"🛍️ <b>{html.escape(data['title'][:200])}</b>"]
            if data.get("price"):
                lines.append(f"💶 Prezzo: <b>{html.escape(data['price'])}</b>")
            if data.get("coupon"):
                lines.append(f"🏷️ {html.escape(data['coupon'])}")
            lines.append(f"🔗 {tag_url}")
            bot.reply_to(m, "\n".join(lines))
        except Exception as e:
            logging.exception("cerca error")
            bot.reply_to(m, f"❌ Errore: {e}")
    else:
        # Modalità "query": per semplicità, spiega come usare link (API non incluse nel base)
        bot.reply_to(m,
            "🔎 Modalità query (senza API) non inclusa nel pacchetto base.\n"
            "Invia direttamente un <b>link Amazon</b> del prodotto per ottenere titolo/prezzo/coupon."
        )

@bot.message_handler(commands=["post"])
def cmd_post(m):
    parts = m.text.split(maxsplit=1)
    if len(parts) == 1:
        bot.reply_to(m, "Usa: <code>/post &lt;link Amazon&gt;</code>")
        return
    url = parts[1].strip()
    if not any(h in url for h in AMZN_HOSTS):
        bot.reply_to(m, "Per favore invia un <b>link Amazon</b>.")
        return
    try:
        data = fetch_product(url)
        tag_url = add_tag_to_url(data["url"], AFFILIATE_TAG)
        post = []
        post.append(f"📍 <b>{html.escape(data['title'][:120])}</b>")
        if data.get("price"):
            post.append(f"💶 {html.escape(data['price'])}")
        if data.get("coupon"):
            post.append(f"☑️ {html.escape(data['coupon'])}")
        post.append(f"🛒 {tag_url}")
        bot.reply_to(m, "\n".join(post))
    except Exception as e:
        logging.exception("post error")
        bot.reply_to(m, f"❌ Errore: {e}")

# ---------- Run ----------
def main():
    logging.info("Cianfrusacc‑IA BASE avviato.")
    bot.infinity_polling(timeout=60, long_polling_timeout=30)

if __name__ == "__main__":
    main()
