# Cianfrusacc‑IA (BASE)

Bot Telegram base per affiliazione Amazon.
- `/cerca <link Amazon>`: titolo, prezzo, coupon (se rilevato), link con tag
- `/post <link Amazon>`: testo pronto per pubblicazione

## Setup rapido (Termux/Server)
```bash
pip install -r requirements.txt
cp settings.json.example settings.json
# poi apri settings.json e compila TOKEN, AFFILIATE_TAG, OWNER_ID
python bot.py
```
